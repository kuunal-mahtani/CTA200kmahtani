def bad_compare(lhs, rhs):

    unnecessary = lhs - rhs

    return rhs == lhs

print(bad_compare(3, 3))
